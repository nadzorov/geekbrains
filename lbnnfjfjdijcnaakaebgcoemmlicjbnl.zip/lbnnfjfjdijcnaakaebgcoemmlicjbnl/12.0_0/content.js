/************************************************************************/
/*                                                                      */
/*      Tile Tabs WE - Generic WebExtension - Content Pages             */
/*                                                                      */
/*      Javascript for Content Pages                                    */
/*                                                                      */
/*      Last Edit - 21 Oct 2020                                         */
/*                                                                      */
/*      Copyright (C) 2015-2020 DW-dev                                  */
/*                                                                      */
/*      Distributed under the GNU General Public License version 2      */
/*      See LICENCE.txt file and http://www.gnu.org/licenses/           */
/*                                                                      */
/************************************************************************/

/************************************************************************/
/*                                                                      */
/* Refer to Google Chrome developer documentation:                      */
/*                                                                      */
/*  https://developer.chrome.com/extensions/content_scripts             */
/*  https://developer.chrome.com/extensions/messaging                   */
/*                                                                      */
/*  https://developer.chrome.com/extensions/match_patterns              */
/*                                                                      */
/*  https://developer.chrome.com/extensions/runtime                     */
/*  https://developer.chrome.com/extensions/storage                     */
/*                                                                      */
/************************************************************************/

"use strict";

/************************************************************************/

/* Global variables */

var guiContainer = null;

var menuIcon,menuBox,leftMenuBox,rightMenuBox;
var menuClose,menuHide,menuRefresh,menuBookmark,menuToggle,menuToggleAll,menuSync;
var menuAbove,menuLeft,menuRight,menuBelow,menuRemove,menuExpand,menuEqualize;
var menuStyle;

var doubleExpand,doubleEqualize,doubleToggleThis,doubleToggleAll,doubleRefresh;

var openLinks;

var ignoreScrollEvent = false;

var menuIconData = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAIAAACQkWg2AAAABGdBTUEAALGPC/xhBQAAAAlwSFlzAAAOuAAADrgBakH1WwAAABl0RVh0U29mdHdhcmUAcGFpbnQubmV0IDQuMC4yMfEgaZUAAAArSURBVDhPY0hoeEASAml48OADJsIqPuAasKJB6geSELoNBLkjVgMJqOEBAGB/U0+/JG2mAAAAAElFTkSuQmCC";
var checkMarkData = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAIAAACQkWg2AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZdEVYdFNvZnR3YXJlAHBhaW50Lm5ldCA0LjAuMjHxIGmVAAAAb0lEQVQ4T2OYcOIbSWioamhYexnOJqwhLLvG2Ni4ZetdCJeABojq3Alr4SIIDUB7ka0GIkzVQITQEJBYYGljD9eDVTUQITR07XvlFhAJ0YNLNRCh+AGiB6gUl2ogQvc0RA8u1UCEroEgGnQaTnwDAHhfLm8ArxBJAAAAAElFTkSuQmCC";

/************************************************************************/

/* Initialize on script load */

if (document.readyState == "complete")
{
    chrome.runtime.sendMessage({ type: "pageLoad" });
}
else
{
    window.addEventListener("load",
    function(event)
    {
        if (document.readyState == "complete") chrome.runtime.sendMessage({ type: "pageLoad" });
    },false);
}

chrome.storage.local.get(null,
function(object)
{
    doubleExpand = object["options-doubleexpand"];
    doubleEqualize = object["options-doubleequalize"];
    doubleToggleThis = object["options-doubletogglethis"];
    doubleToggleAll = object["options-doubletoggleall"];
    doubleRefresh = object["options-doublerefresh"];
    
    openLinks = object["options-openlinks"];
    
    /* Construct menu */
    
    constructQuickMenu();
    
    /* Add listeners */
    
    addListeners();
});

/************************************************************************/

/* Add listeners */

function addListeners()
{
    /* Storage changed listener */
    
    chrome.storage.onChanged.addListener(
    function(changes,areaName)
    {
        if ("options-doubleexpand" in changes) doubleExpand = changes["options-doubleexpand"].newValue;
        if ("options-doubleequalize" in changes) doubleEqualize = changes["options-doubleequalize"].newValue;
        if ("options-doubletogglethis" in changes) doubleToggleThis = changes["options-doubletogglethis"].newValue;
        if ("options-doubletoggleall" in changes) doubleToggleAll = changes["options-doubletoggleall"].newValue;
        if ("options-doublerefresh" in changes) doubleRefresh = changes["options-doublerefresh"].newValue;
        
        if ("options-openlinks" in changes) openLinks = changes["options-openlinks"].newValue;
    });
    
    /* Message received listener */
    
    chrome.runtime.onMessage.addListener(
    function(message,sender,sendResponse)
    {
        switch (message.type)
        {
            /* Messages from background page */
            
            case "addQuickMenu":
                
                addQuickMenu(message.position,message.expanded,message.syncscroll);
                
                break;
                
            case "removeQuickMenu":
                
                removeQuickMenu();
                
                break;
                
            case "addListeners":
                
                document.addEventListener("click",onClick,true);
                document.addEventListener("auxclick",onAuxClick,true);
                document.addEventListener("dblclick",onDblClick,true);
                document.addEventListener("scroll",onScroll,true);
                
                break;
                
            case "removeListeners":
                
                document.removeEventListener("click",onClick,true);
                document.removeEventListener("auxclick",onClick,true);
                document.removeEventListener("dblclick",onDblClick,true);
                document.removeEventListener("scroll",onScroll,true);
                
                break;
                
            case "initScrollPosn":
                
                ignoreScrollEvent = true;
                
                window.scrollTo(message.scrollx,message.scrolly);
                
                break;
                
            case "setScrollPosn":
                
                ignoreScrollEvent = true;
                
                window.scrollBy(message.deltax,message.deltay);
                
                break;
        }
    });
}

/************************************************************************/

/* Quick menu functions */

function constructQuickMenu()
{
    guiContainer = document.createElement("div");
    guiContainer.setAttribute("id","tiletabs-gui-container");
    
    menuIcon = document.createElement("div");
    menuIcon.setAttribute("id","tiletabs-menuicon");
    guiContainer.appendChild(menuIcon);
    
    menuBox = document.createElement("div");
    menuBox.setAttribute("id","tiletabs-menubox");
    guiContainer.appendChild(menuBox);
    
    leftMenuBox = document.createElement("div");
    leftMenuBox.setAttribute("id","tiletabs-leftmenubox");
    menuBox.appendChild(leftMenuBox);
    
    rightMenuBox = document.createElement("div");
    rightMenuBox.setAttribute("id","tiletabs-rightmenubox");
    menuBox.appendChild(rightMenuBox);
    
    menuClose = document.createElement("div");
    menuClose.setAttribute("class","tiletabs-menuitem");
    menuClose.innerText = "Close Layout";
    leftMenuBox.appendChild(menuClose);
    
    menuHide = document.createElement("div");
    menuHide.setAttribute("class","tiletabs-menuitem");
    menuHide.innerText = "Hide Layout";
    leftMenuBox.appendChild(menuHide);
    
    menuRefresh = document.createElement("div");
    menuRefresh.setAttribute("class","tiletabs-menuitem");
    menuRefresh.innerText = "Refresh Layout";
    leftMenuBox.appendChild(menuRefresh);
    
    menuBookmark = document.createElement("div");
    menuBookmark.setAttribute("class","tiletabs-menuitem");
    menuBookmark.innerText = "Bookmark Layout";
    leftMenuBox.appendChild(menuBookmark);
    
    menuToggle = document.createElement("div");
    menuToggle.setAttribute("class","tiletabs-menuitem");
    menuToggle.innerText = "Toggle > This";
    leftMenuBox.appendChild(menuToggle);
    
    menuToggleAll = document.createElement("div");
    menuToggleAll.setAttribute("class","tiletabs-menuitem");
    menuToggleAll.innerText = "Toggle > All";
    leftMenuBox.appendChild(menuToggleAll);
    
    menuSync = document.createElement("div");
    menuSync.setAttribute("class","tiletabs-menuitem");
    menuSync.setAttribute("syncscroll","false");
    menuSync.innerText = "Sync Scroll";
    menuSync.appendChild(document.createElement("div"));
    leftMenuBox.appendChild(menuSync);
    
    menuAbove = document.createElement("div");
    menuAbove.setAttribute("class","tiletabs-menuitem");
    menuAbove.innerText = "Add Tile > Above";
    rightMenuBox.appendChild(menuAbove);
    
    menuLeft = document.createElement("div");
    menuLeft.setAttribute("class","tiletabs-menuitem");
    menuLeft.innerText = "Add Tile > Left";
    rightMenuBox.appendChild(menuLeft);
    
    menuRight = document.createElement("div");
    menuRight.setAttribute("class","tiletabs-menuitem");
    menuRight.innerText = "Add Tile > Right";
    rightMenuBox.appendChild(menuRight);
    
    menuBelow = document.createElement("div");
    menuBelow.setAttribute("class","tiletabs-menuitem");
    menuBelow.innerText = "Add Tile > Below";
    rightMenuBox.appendChild(menuBelow);
    
    menuRemove = document.createElement("div");
    menuRemove.setAttribute("class","tiletabs-menuitem");
    menuRemove.innerText = "Remove Tile";
    rightMenuBox.appendChild(menuRemove);
    
    menuExpand = document.createElement("div");
    menuExpand.setAttribute("class","tiletabs-menuitem");
    menuExpand.innerText = "Expand Tile";
    rightMenuBox.appendChild(menuExpand);
    
    menuEqualize = document.createElement("div");
    menuEqualize.setAttribute("class","tiletabs-menuitem");
    menuEqualize.innerText = "Equalize Tiles";
    rightMenuBox.appendChild(menuEqualize);
    
    menuStyle = document.createElement("style");
    menuStyle.innerText = 
    
        "#tiletabs-menuicon," +
        "#tiletabs-menubox," +
        "#tiletabs-menubox *" +
        "{ " +
        "    initial: all !important;" +
        "} " +
        
        "#tiletabs-menuicon," +
        "#tiletabs-menubox," +
        "#tiletabs-menubox *" +
        "{ " +
        "    font-family: 'Segoe UI','Helvetica Neue',Ubuntu,Arial !important;" +
        "    font-size: 12px !important;" +
        "    color: black !important;" +
        "    white-space: nowrap !important;" +
        "    cursor: default !important;" +
        "    -moz-user-select: none !important;" +
        "    -webkit-user-select: none !important;" +
        "} " +
        
        "#tiletabs-menuicon" +
        "{ " +
        "    position: fixed !important;" +
        /*   top: 0px !important; */
        /*   left: 0px !important; */
        "    width: 16px !important;" +
        "    height: 16px !important;" +
        "    margin: 1px !important;" +
        "    padding: 0px !important;" +
        "    border: 1px solid #FFFFFF !important;" +
        "    background: url(" + menuIconData + ") no-repeat !important;" +
        "    z-index: 2147483647 !important;" +
       "} " +
        
        "#tiletabs-menubox" +
        "{ " +
        "    position: fixed !important;" +
        /*   top: 0px !important; */
        /*   left: 0px !important; */
        "    width: 207px !important;" +
        "    margin: 1px !important;" +
        "    padding: 0px !important;" +
        "    border: 1px solid #C0C0C0 !important;" +
        "    background-color: #F0F0F0 !important;" +
        "    z-index: 2147483647 !important;" +
        "} " +
        
        "#tiletabs-leftmenubox" +
        "{ " +
        "    display: inline-block !important;" +
        "    width: 103px !important;" +
        "    border-right: 1px solid #C0C0C0 !important;" +
        "} " +
        
        "#tiletabs-rightmenubox" +
        "{ " +
        "    display: inline-block !important;" +
        "    width: 103px !important;" +
        "} " +
        
        ".tiletabs-menuitem" +
        "{ " +
        "    margin: 0px !important;" +
        "    padding: 2px 4px 2px 4px !important;" +
        "} " +
        
        ".tiletabs-menuitem div" +
        "{ " +
        "    display: none !important;" +
        "} " +
        
        ".tiletabs-menuitem[syncscroll='true'] div" +
        "{ " +
        "    display: inline-block !important;" +
        "    position: relative !important;" +
        "    left: 28px !important;" +
        "    top: 3px !important;" +
        "    width: 16px !important;" +
        "    height: 16px !important;" +
        "    background: url(" + checkMarkData + ") no-repeat !important;" +
        "} " +
        
        ".tiletabs-menuitem:hover" +
        "{ " +
        "    background-color: #90C8F6 !important;" +
        "} " ;
       
    guiContainer.appendChild(menuStyle);
}

function addQuickMenu(position,expanded,syncScroll)
{
    var vertical = new Array("top","top","bottom","bottom");
    var horizontal = new Array("left","right","left","right");
    
    menuIcon.style.removeProperty("top");
    menuIcon.style.removeProperty("bottom");
    menuIcon.style.removeProperty("left");
    menuIcon.style.removeProperty("right");
    
    menuIcon.style.setProperty(vertical[position],"0px","important");
    menuIcon.style.setProperty(horizontal[position],"0px","important");
    
    menuBox.style.removeProperty("top");
    menuBox.style.removeProperty("bottom");
    menuBox.style.removeProperty("left");
    menuBox.style.removeProperty("right");
    
    menuBox.style.setProperty(vertical[position],"0px","important");
    menuBox.style.setProperty(horizontal[position],"0px","important");
    
    menuExpand.innerText = expanded ? "Contract Tile" : "Expand Tile";
    
    menuSync.setAttribute("syncscroll",syncScroll);
    
    if (guiContainer.parentNode != null) return;
    
    document.documentElement.appendChild(guiContainer);
    
    menuIcon.style.setProperty("display","block","important");
    
    menuBox.style.setProperty("display","none","important");
    
    menuIcon.addEventListener("mouseenter",onMouseEnterMenuIcon,false);
    menuBox.addEventListener("mouseleave",onMouseLeaveMenuBox,false);
    
    menuClose.addEventListener("click",onClickMenuClose,false);
    menuHide.addEventListener("click",onClickMenuHide,false);
    menuRefresh.addEventListener("click",onClickMenuRefresh,false);
    menuBookmark.addEventListener("click",onClickMenuBookmark,false);
    menuToggle.addEventListener("click",onClickMenuToggle,false);
    menuToggleAll.addEventListener("click",onClickMenuToggleAll,false);
    menuSync.addEventListener("click",onClickMenuSync,false);
    
    menuAbove.addEventListener("click",onClickMenuAbove,false);
    menuLeft.addEventListener("click",onClickMenuLeft,false);
    menuRight.addEventListener("click",onClickMenuRight,false);
    menuBelow.addEventListener("click",onClickMenuBelow,false);
    menuRemove.addEventListener("click",onClickMenuRemove,false);
    menuExpand.addEventListener("click",onClickMenuExpand,false);
    menuEqualize.addEventListener("click",onClickMenuEqualize,false);
}

function removeQuickMenu()
{
    if (guiContainer.parentNode == null) return;
    
    menuIcon.removeEventListener("mouseenter",onMouseEnterMenuIcon,false);
    menuBox.removeEventListener("mouseleave",onMouseLeaveMenuBox,false);
    
    menuClose.removeEventListener("click",onClickMenuClose,false);
    menuHide.removeEventListener("click",onClickMenuHide,false);
    menuRefresh.removeEventListener("click",onClickMenuRefresh,false);
    menuBookmark.removeEventListener("click",onClickMenuBookmark,false);
    menuToggle.removeEventListener("click",onClickMenuToggle,false);
    menuToggleAll.removeEventListener("click",onClickMenuToggleAll,false);
    menuSync.removeEventListener("click",onClickMenuSync,false);
    
    menuAbove.removeEventListener("click",onClickMenuAbove,false);
    menuLeft.removeEventListener("click",onClickMenuLeft,false);
    menuRight.removeEventListener("click",onClickMenuRight,false);
    menuBelow.removeEventListener("click",onClickMenuBelow,false);
    menuRemove.removeEventListener("click",onClickMenuRemove,false);
    menuExpand.removeEventListener("click",onClickMenuExpand,false);
    menuEqualize.removeEventListener("click",onClickMenuEqualize,false);
    
    document.documentElement.removeChild(guiContainer);
}

/************************************************************************/

/* Mouse event functions */

function onMouseEnterMenuIcon(event)
{
    menuIcon.style.setProperty("display","none","important");
    
    menuBox.style.setProperty("display","block","important");
}

function onMouseLeaveMenuBox(event)
{
    menuIcon.style.setProperty("display","block","important");
    
    menuBox.style.setProperty("display","none","important");
}

function onClickMenuClose(event)
{
    chrome.runtime.sendMessage({ type: "closeLayout" });
}

function onClickMenuHide(event)
{
    chrome.runtime.sendMessage({ type: "hideLayout" });
}

function onClickMenuRefresh(event)
{
    chrome.runtime.sendMessage({ type: "refreshLayout" });
    
    onMouseLeaveMenuBox();
}

function onClickMenuBookmark(event)
{
    chrome.runtime.sendMessage({ type: "bookmarkLayout" });
    
    onMouseLeaveMenuBox();
}

function onClickMenuToggle(event)
{
    chrome.runtime.sendMessage({ type: "toggleToolbars" });
}

function onClickMenuToggleAll(event)
{
    chrome.runtime.sendMessage({ type: "toggleToolbarsAll" });
}

function onClickMenuSync(event)
{
    chrome.runtime.sendMessage({ type: "syncScroll" });
    
    onMouseLeaveMenuBox();
}

function onClickMenuAbove(event)
{
    chrome.runtime.sendMessage({ type: "addTile", direction: "above" });
}

function onClickMenuLeft(event)
{
    chrome.runtime.sendMessage({ type: "addTile", direction: "left" });
}

function onClickMenuRight(event)
{
    chrome.runtime.sendMessage({ type: "addTile", direction: "right" });
}

function onClickMenuBelow(event)
{
    chrome.runtime.sendMessage({ type: "addTile", direction: "below" });
}

function onClickMenuRemove(event)
{
    chrome.runtime.sendMessage({ type: "removeTile" });
}

function onClickMenuExpand(event)
{
    chrome.runtime.sendMessage({ type: "expandTile" });
}

function onClickMenuEqualize(event)
{
    chrome.runtime.sendMessage({ type: "equalizeTiles" });
}

function onClick(event)
{
    var element;
    
    if (typeof event.isTrusted != "undefined" && !event.isTrusted) return;  /* event.isTrusted undefined before Chrome 46 */
    
    if ((openLinks == 1 && event.button == 0 && event.ctrlKey) ||
        (openLinks == 2 && event.button == 1 && !event.ctrlKey) ||  /* for backwards compatibility */
        (openLinks == 3 && event.button == 1 && event.ctrlKey))     /* for backwards compatibility */
    {
        element = event.target;
        while (element && !element.href) element = element.parentNode;
        
        if (element) chrome.runtime.sendMessage({ type: "openInNext", shift: event.shiftKey, url: element.href });
        
        event.preventDefault();
        event.stopPropagation();
    }
}

function onAuxClick(event)
{
    var element;
    
    if (typeof event.isTrusted != "undefined" && !event.isTrusted) return;  /* event.isTrusted undefined before Chrome 46 */
    
    if ((openLinks == 2 && event.button == 1 && !event.ctrlKey) ||
        (openLinks == 3 && event.button == 1 && event.ctrlKey))
    {
        element = event.target;
        while (element && !element.href) element = element.parentNode;
        
        if (element) chrome.runtime.sendMessage({ type: "openInNext", shift: event.shiftKey, url: element.href });
        
        event.preventDefault();
        event.stopPropagation();
    }
}

function onDblClick(event)
{
    var element,selection,range,rects;
    
    if (typeof event.isTrusted != "undefined" && !event.isTrusted) return;  /* event.isTrusted undefined before Chrome 46 */
    
    if ((doubleExpand && !event.altKey && !(event.ctrlKey || event.metaKey) && !event.shiftKey) ||
        (doubleEqualize && !event.altKey && !(event.ctrlKey || event.metaKey) && event.shiftKey) ||
        (doubleToggleThis && !event.altKey && (event.ctrlKey || event.metaKey) && !event.shiftKey) ||
        (doubleToggleAll && !event.altKey && (event.ctrlKey || event.metaKey) && event.shiftKey) ||
        (doubleRefresh && event.altKey && !(event.ctrlKey || event.metaKey) && !event.shiftKey))
    {
        element = event.target;
        while (element && element.localName != "a" && element.localName != "area") element = element.parentNode;
        
        if (!element)  /* current target not inside link */
        {
            selection = document.getSelection();
            range = selection.getRangeAt(0);
            rects = range.getClientRects();
            
            if (rects.length == 0 ||
                event.clientX < rects[0].left-10 || event.clientX > rects[0].right+10 ||
                event.clientY < rects[0].top-10 || event.clientY > rects[0].bottom+10)  /* cursor not inside selection */
            {
                selection.removeAllRanges();
                
                chrome.runtime.sendMessage({ type: "onDblClick", alt: event.altKey, ctrl: (event.ctrlKey || event.metaKey), shift: event.shiftKey });
            }
        }
    }
}

function onScroll(event)
{
    if (!ignoreScrollEvent) chrome.runtime.sendMessage({ type: "onScroll", scrollx: window.scrollX, scrolly: window.scrollY });
    
    ignoreScrollEvent = false;
}

/************************************************************************/
