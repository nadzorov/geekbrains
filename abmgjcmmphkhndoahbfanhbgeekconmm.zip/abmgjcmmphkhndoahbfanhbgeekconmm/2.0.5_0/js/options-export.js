$(document).ready(function() {
	
	var Export = {
		
		Empty:	function() {
			return '';
		},
		
		InsertText2:	function() {
			return JSON.stringify(InsertTextStore.getTexts());
		}
		
	};
	
	$('#export-format').bind('change', function(e) {
		$('#export-contents')
			.val(Export[$(this).val()]());
		
	});
	
});