$(document).ready(function() {
	
	// defaultRichText
	$('#settings-defaultRichText').bind('change', function(e) {
		InsertTextSettings.set('defaultRichText', $(this).val());
		toast('Option saved');
	});
	$('#settings-defaultRichText')
		.val(InsertTextSettings.get('defaultRichText'));
	
});