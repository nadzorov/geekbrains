var InsertTextMenu = {
	
	contexts:	['editable'],
	
	items:		{
		
		root:	function() {			
			return chrome.contextMenus.create({
				'title':	'Insert Text',
				'contexts':	InsertTextMenu.contexts,
				'documentUrlPatterns':	[
					'<all_urls>'
				]
			});			
		},
		
		separator:	function(parent) {
			return chrome.contextMenus.create({
				'type':		'separator',
				'contexts':	InsertTextMenu.contexts,
				'parentId':	parent
			});
		},
		
		manage:	function(parent) {
			return chrome.contextMenus.create({
				'title':	'Create/Edit Texts',
				'contexts':	InsertTextMenu.contexts,
				'parentId':	parent,
				'onclick':	function(info, tab) {		
					window.open(chrome.extension.getURL('options.html'));		
				}
			});
		},
		
		text: function(text, parent) {
			return chrome.contextMenus.create({
				'title':	text.name,
				'contexts':	InsertTextMenu.contexts,
				'parentId':	parent,
				'onclick':	function(info, tab) {
					if (text.type == 'text') {
						// send
						chrome.tabs.sendRequest(tab.id, {
							text:	text.text,
							html:	text.html == 'true'
						});
					}
				}
			});
		}
		
	},
	
	addTexts: function(folder, parent) {
		
		for (var i=0,ilen=folder.length; i<ilen; i++) {
			
			var text = folder[i];
			
			var menuId = this.items.text(text, parent);
			
			if (text.items) {
				
				this.addTexts(text.items, menuId);
				
			}
			
		}
		
	},
	
	generate:	function() {
		var _this = this;
		
		// remove all menus and start again
		chrome.contextMenus.removeAll(function() {
			
			// get texts
			var texts = InsertTextStore.getTexts();
			
			var root = _this.items.root();
			
			_this.addTexts(texts, root);
			
			// separator
			if (texts.length > 0) {
				_this.items.separator(root);
			}
			
			// manage texts
			_this.items.manage(root)
			
		});
		
	}
	
};