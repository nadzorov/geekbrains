$(document).ready(function() {
	
	// sidebar
	$('div', '#tab-container').live('click', function(e) {
		
		// remove active
		$('div.active', '#tab-container').removeClass('active');
		
		// add active
		$(this).addClass('active');
		
		// hide current content
		$('div.tab-content.show').removeClass('show');
		
		// show selected content
		$('#' + this.dataset.content).addClass('show');
		
	});
	
	var toasting = false;
	
	/**
	 * toast
	 */
	window.toast = function(text) {
		
		if (!toasting) {
			
			toasting = true;
			
			$('#toast').html(text || 'Update successful');
		
			$('#toast')
				.show()
				.animate({
					top: '+=55'
				}, 500)
				.delay(1000)
				.animate({
					top: '-=55'
				}, 500, function() {
					$('#toast').hide();
					toasting = false;
				});
				
		}
		
	};
		
	
});