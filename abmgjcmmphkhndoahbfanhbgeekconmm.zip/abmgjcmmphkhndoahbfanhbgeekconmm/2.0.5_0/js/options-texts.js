$(document).ready(function() {
	
	var Tree = {
		
		el:		$('#texts-tree'),
		
		dom:	document.getElementById('texts-tree'),
		
		/**
		 * Loads the text tree recursively from the root
		 */
		load:	function(folder) {
			
			// loop through each item
			for (var i=0, ilen=folder.length; i<ilen; i++) {
				
				// get current item
				var text = folder[i];
				
				// add it
				Node.add(text);
				
				if ('folder' === text.type) {
					
					this.load(text.items);
					
				}
				
			}
			
		},
		
		reload:	function(noSelect) {
			
			// get selected id
			var selectedId = Node.selected && Node.selected.dataset.id || null;
			
			// remove all children
			this.el.empty();
			
			// empty folder select
			Folder.empty();
			
			// rebuild
			this.load(InsertTextStore.getTexts());
			
			if (!noSelect && selectedId) {
				Node.select(document.getElementById('texts-text' + selectedId));
			}
			else {
				this.clearSelections();
			}
			
		},
		
		/**
		 * Clears all selections from the tree
		 */
		clearSelections:	function() {
			
			$('li', this.el).removeClass('selected');
			
		}
		
	};
	
	// expose reload for other sections
	window.reloadTextsTree = function() {
		Tree.reload.call(Tree);
	};
	
	var Node = {
		
		/**
		 * Adds a node to the text tree
		 */
		add:	function(text, select) {
			
			// create element
			var li	= document.createElement('li');
			var $li	= $(li)
						.addClass(text.type)
						.attr('id', 'texts-text' + text.id)
						.html(text.name);
			
			// update data
			li.dataset.id		= text.id;
			li.dataset.type		= text.type;
			li.dataset.level	= text.level;
			li.dataset.parent	= text.parent;
			li.dataset.name		= text.name;
			li.dataset.text		= text.text;
			li.dataset.html		= text.html;
			
			// set dimensions
			this.dimensions(li);

			// add to tree
			Tree.el.append(li);
							
			// if folder
			if (text.type === 'folder') {

				// add it to folder list
				Folder.add(text);

			}

			// select node
			if (true === select) {
				this.select(li);
			}
			
			// return dom
			return li;
			
		},
		
		/**
		 * Currently selected dom node
		 */
		selected:	null,
		
		/**
		 * Selects a node from the text tree
		 */
		select:	function(dom) {
			
			// record selection
			this.selected = dom;
			
			// clear active selections
			Tree.clearSelections();
			
			// add selected class
			$(dom).addClass('selected');
			
			// show content
			Content.show(dom.dataset);
			
			// filter folder select
			Folder.filter(dom.dataset.id);
			
			Toolbar.up();
			Toolbar.down();
			
		},
		
		/**
		 * Updates the selected node with data from content
		 * and saves the text
		 */
		update:	function() {
			
			var data = Content.getData();
			
			var folderChanged = data.parent != this.selected.dataset.parent;
			
			// update dataset
			this.selected.dataset.parent	= data.parent;
			this.selected.dataset.name		= data.name;
			this.selected.dataset.text		= data.text;
			this.selected.dataset.html		= data.html;
			
			// update dom html
			this.selected.innerText			= data.name;
			
			// update folder select
			if ('folder' === this.selected.dataset.type) {
				
				Folder.update(this.selected.dataset.id, data.name);
				
			}
			
			// update text
			InsertTextStore.update(this.selected.dataset.id, data);
			
			if (folderChanged) {
				this.changeFolder(data.parent);
			}
			
			// generate menu
			InsertTextMenu.generate();
			
			toast();
			
		},
		
		remove:	function() {
			
			// remove text
			InsertTextStore.remove(this.selected.dataset.id);
			
			// remove node
			$(this.selected).remove();
			
			// remove from folder select
			if ('folder' === this.selected.dataset.type) {
				
				Folder.remove(this.selected.dataset.id);
				
			}
			
			// unset selected
			this.selected = null;
			
			// reload tree
			Tree.reload();
			
			// hide content
			Content.hide();
					
			// generate menu
			InsertTextMenu.generate();
			
		},
		
		/**
		 * Change the folder of the selected text, and children
		 * returns the new level
		 * 
		 * @return int
		 */
		changeFolder:	function(parentId) {
			
			// get text
			var text = InsertTextStore.getTextById(this.selected.dataset.id);
			
			if (parseInt(parentId, 10) === 0) {
				
				text.level = 0;
				Folder.update(text.id, text.name, text.level);
				
			}
			else {
				
				// get new parent
				var parent		= $('#texts-text' + parentId);
				var parentLevel	= parseInt(parent.get(0).dataset.level, 10);

				// set level as parent level + 1
				text.level = parentLevel + 1;
								
			}
			
			var updateChildLevels = function(folder, level) {
				
				if (folder.items) {
					
					for (var i=0,ilen=folder.items.length; i<ilen; i++) {
						
						var text = folder.items[i];
						
						text.level = level;
						
						Folder.update(text.id, text.name, text.level);
						
						if (text.type == 'folder') {
							
							updateChildLevels(text, level+1);
							
						}
						
					}
					
				}
				
			};
			
			if (text.type == 'folder') {
				updateChildLevels(text, text.level+1);
			}
						
			InsertTextStore.setTexts();
			
			Tree.reload();
			
		},
		
		toggleHTML:	function() {
			
			$('#texts-html').bind('change', function() {
				
				if (this.value == 'true') {
					Content.showEditor();
				}
				else {
					Content.hideEditor();
				}
				
			});
			
		},
		
		dimensions:	function(dom) {
			
			var level = parseInt(dom.dataset.level, 10);
			
			$(dom).css({
				'background-position-x':	(level*20) + 'px',
				'padding-left':				((level+1)*20) + 'px'
			});
			
		},
		
		getChildren:	function(parent, position, exclude) {
			
			var parentId	= parent.dataset.id;
			var parentLevel	= parent.dataset.level;
			
			var children = [];
			
			var nodes = $('li', Tree.dom);
			
			var inParent = false;
			
			for (var i=0,ilen=nodes.length; i<ilen; i++) {
				
				if (inParent && nodes[i].dataset.level > parentLevel && nodes[i] != exclude) {
					children.push(nodes[i]);
				}
				
				if (nodes[i].dataset.id == parentId) {
					
					inParent = true;
					
				}
				
			}
			
			var child;			
			switch (position) {
				
				case 'first':
					child = children[0];
					break;
					
				case 'last':
					child = children[children.length-1];
					break;
					
				default:
					child = children;
					break;
				
			}
			
			return child;
			
		},
		
		getDirectChildren:	function(parent) {
			
			var children = [];
			
			var nodes = $('li', Tree.dom);
			
			for (var i=0,ilen=nodes.length; i<ilen; i++) {
				
				var dom = nodes[i];
				
				if (dom.dataset.parent == parent) {
					children.push(dom);
				}
				
			}
			
			return children;
			
		}
		
	};
	
	var Content = {
		
		el:		$('#texts-content'),
		
		dom:	document.getElementById('texts-content'),
		
		load:	function() {
			
			$('#texts-button-save')
				.button()
				.bind('click', function() {
					Node.update();
				});
			$('#texts-button-delete')
				.button()
				.bind('click', function() {
					var html, confirmText;
					if (Node.selected.dataset.type == 'text') {
						html		= 'Are you sure you want to delete this text?';
						confirmText	= 'Yes, delete text';
					}
					else {
						html		= 'Are you sure you want to delete this folder? All items in it will also be deleted.';
						confirmText	= 'Yes, delete folder and contents';
					}
					
					var buttons = {
						'Cancel':	function() {
							$(this).dialog('close');
						}
					};
					buttons[confirmText] = function() {
						Node.remove();
						$(this).dialog('close');
					};
					
					$('#dialog')
						.html(html)
						.dialog({
							modal:		true,
							resizable:	false,
							title:		'Confirm',
							width:		350,
							height:		150,
							buttons:	buttons
						});
						
				});
			
		},
		
		/**
		 * Shows the content panel and optionally populates it
		 */
		show:	function(data) {
			
			// show content
			this.el.show();
			
			// if data
			if (data) {
					
				if (data.type == 'text' && data.html == 'true') {
					this.showEditor();
				}
				else {
					this.hideEditor();
				}
				
				// populate data
				this.populate(data);
				
				if (data.type == 'folder') {
					
					$('#texts-html').hide();
					$('#texts-text').hide();
					
				}
				else {
					
					$('#texts-html').show();
					
					if (data.html == 'false') {
						$('#texts-text').show();
					}
					
				}
				
			}
			
		},
		
		/**
		 * Hides content and unpopulates it
		 **/
		hide:	function() {
			
			// hide content
			this.el.hide();
			
			// unpopulate data
			this.unpopulate();
			
			// show texts if it was hidden
			$('#texts-text').show();
			
		},
		
		/**
		 * Populates the content
		 */
		populate:	function(data) {
			
			$('#texts-html').val(data.html);
			$('#texts-folder').val(data.parent);
			$('#texts-name').val(data.name);
			$('#texts-text').val(data.text);
			
		},
		
		/**
		 * Unpopulates the content
		 */
		unpopulate:	function() {
			
			$('#texts-folder').val("0");
			$('#texts-name').val("");
			$('#texts-text').val("");
			
		},
		
		/**
		 * Returns the current content data
		 */
		getData:	function() {
			
			return {
				'parent':	$('#texts-folder').val(),
				'name':		$('#texts-name').val(),
				'text':		$('#texts-text').val(),
				'html':		$('#texts-html').val()
			};
			
		},
		
		showEditor:	function() {
			
			this.hideEditor();
			$('#texts-text')
				.ckeditor({
					toolbar:	[
						{ name: 'basicstyles',	items : [ 'Bold','Italic','Underline','Strike' ] },
						{ name: 'paragraph',	items : [ 'NumberedList','BulletedList','-','Outdent','Indent' ] },
						{ name: 'align',		items : [ 'JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock' ] },
						{ name: 'links',		items : [ 'Link','Unlink' ] },
						{ name: 'reset',		items : [ 'RemoveFormat' ] },
						{ name: 'source',		items : [ 'Source' ] },
						{ name: 'styles',		items : [ 'Format','Font','FontSize' ] }
					]
				});
			
		},
		
		hideEditor:	function() {
			
			try {
				var editor = $('#texts-text').show().ckeditorGet();
				editor.destroy();
			}
			catch (e) {}
			
		}
		
	};
	
	var Folder = {
		
		el:		$('#texts-folder'),
		
		dom:	document.getElementById('texts-folder'),
		
		/**
		 * Add a folder to the select
		 */
		add:	function(data) {
			
			var indent = '';
			for (var i=0;i<data.level;i++) {
				indent += '&nbsp;&nbsp;&nbsp;&nbsp;';
			}
			
			this.el.append('<option value="' + data.id + '">' + indent + data.name + '</option>');
			
		},
		
		/**
		 * Remove a folder from the select
		 */
		remove:	function(id) {
			
			$('option[value=' + id + ']', this.dom).remove();
			
		},
		
		/**
		 * Update a folder name in the select
		 */
		update:	function(id, name, level) {
			
			var indent = '';
			if (level) {
				for (var i=0;i<level;i++) {
					indent += '&nbsp;&nbsp;&nbsp;&nbsp;';
				}
			}
			
			$('option[value=' + id + ']', this.dom).html(indent + name);
			
		},
		
		empty:	function() {
			
			this.el.empty();
			
			this.el.append('<option value="0">No Folder</option>');
			
		},
		
		/**
		 * Filter out a folder and children
		 */
		filter: function(id) {
			
			// unfilter first
			this.unfilter();
			
			$('option[value=' + id + ']', this.dom).attr('disabled', 'disabled');
			
			// hide children
			if ('folder' == Node.selected.dataset.type) {
				
				var children = Node.getChildren(Node.selected);

				for (var i=0, ilen=children.length; i<ilen; i++) {
					if ('folder' == children[i].dataset.type) {
						$('option[value=' + children[i].dataset.id + ']', this.dom).attr('disabled', 'disabled');
					}
				}
				
			}
			
		},
		
		/**
		 * Unfilter folder select
		 */
		unfilter: function() {
			
			$('option[disabled=disabled]', this.dom).removeAttr('disabled');
			
		}
		
	};
	
	var Toolbar = {
		
		load:	function() {
			
			var _this = this;
			
			$('#texts-toolbar-text-add').bind('click', function(e) {
				_this.addText();
			});
			
			$('#texts-toolbar-folder-add').bind('click', function(e) {
				_this.addFolder();
			});
			
			$('#texts-toolbar-move-up').bind('click', function(e) {
				if (!$(this).hasClass('disabled')) {
					_this.moveUp();
				}
			});
			
			$('#texts-toolbar-move-down').bind('click', function(e) {
				if (!$(this).hasClass('disabled')) {
					_this.moveDown();
				}
			});
			
		},
		
		addText:	function() {
			
			// get default data
			var data = InsertTextStore.getDefaultText('text');
			
			// add node
			Node.add(data, true);
			
			// save text
			InsertTextStore.add(data);
			
			// generate menu
			InsertTextMenu.generate();
			
			
		},
		
		addFolder:	function() {
			
			// get default data
			var data = InsertTextStore.getDefaultText('folder');
			
			// add node
			Node.add(data, true);
			
			// save text
			InsertTextStore.add(data);
						
			// generate menu
			InsertTextMenu.generate();
			
		},
		
		moveUp:	function() {
			
			// get same parent nodes
			var nodes = Node.getDirectChildren(Node.selected.dataset.parent);
			
			// get index
			var selectedIndex = nodes.indexOf(Node.selected);
			
			// update position
			InsertTextStore.move(Node.selected.dataset.id, selectedIndex, 'up');
			
			// reload tree
			Tree.reload();
			
		},
		
		up:	function() {
			
			var nodes = Node.getDirectChildren(Node.selected.dataset.parent);
			
			if (nodes.length > 0) {
				
				if (nodes[0] != Node.selected) {
					$('#texts-toolbar-move-up').removeClass('disabled');
				}
				else {
					$('#texts-toolbar-move-up').addClass('disabled');
				}
				
			}
			
		},
		
		moveDown:	function() {
			
			// get same parent nodes
			var nodes = Node.getDirectChildren(Node.selected.dataset.parent);
			
			// get index
			var selectedIndex = nodes.indexOf(Node.selected);
			
			// update position
			InsertTextStore.move(Node.selected.dataset.id, selectedIndex, 'down');
			
			// reload tree
			Tree.reload();
			
		},
		
		down:	function() {
			
			var nodes = Node.getDirectChildren(Node.selected.dataset.parent);
			
			if (nodes.length > 0) {
				
				if (nodes[nodes.length-1] != Node.selected) {
					$('#texts-toolbar-move-down').removeClass('disabled');
				}
				else {
					$('#texts-toolbar-move-down').addClass('disabled');
				}
				
			}
			
		}
		
	};
	
	Tree.load(InsertTextStore.getTexts());
	Toolbar.load();
	Content.load();
	Node.toggleHTML();
		
	$('li', this.dom).live('click', function(e) {
		Node.select(this);
	});
	
});