var InsertTextSettings = {
	
	settings:	null,
	
	getSettings:	function() {
		
		if (null === this.settings) {

			var settings = localStorage.settings;

			if (settings) {			
				settings = JSON.parse(settings);
			}
			else {
				settings = {};			
			}
			
			this.settings = settings;
			
		}
		
		return this.settings;
		
	},
	
	setSettings:	function() {
		
		localStorage.settings = JSON.stringify(this.getSettings());
		
	},
	
	init:	function() {
		
		var settings = this.getSettings();
		
		if (!settings.hasOwnProperty('defaultRichText')) {
			settings.defaultRichText = 'false';
		}
		
		this.setSettings();
		
	},
	
	set:	function(name, value) {
		
		var settings = this.getSettings();
		
		settings[name] = value;
		
		this.setSettings();
		
	},
	
	get:	function(name) {
		
		var settings = this.getSettings();
		
		return settings[name];
		
	}
	
};

InsertTextSettings.init();