$(document).ready(function() {
	
	var Import = {
		
		Empty:	function() {
			$('#dialog')
				.html('Please select a format')
				.dialog({
					modal:		true,
					resizable:	false,
					title:		'Error',
					width:		200,
					height:		60
				});
			return false;
		},
		
		InsertText2:	function(contents, type) {
			var error = "";
			// check format
			if (!/^\[\{"id"\:.+\}\]$/.test(contents)) {
				error = 'Content does not appear to be in the correct format';
			}
			try {
				JSON.parse(contents);
			}
			catch (e) {
				error = 'Content does not appear to be in the correct format';
			}
			
			if (error) {
				$('#dialog')
					.html(error)
					.dialog({
						modal:		true,
						resizable:	false,
						title:		'Error',
						width:		250,
						height:		75
					});
				return false;
			}
			
			// re-assign ids
			var reassignIds = function(folder, parent) {
				for (var i=0,ilen=folder.length; i<ilen; i++) {
					var text = folder[i];
					text.id = InsertTextStore.nextId();
					if (parent) {
						text.parent = parent;
					}
					if (text.items) {
						reassignIds(text.items, text.id);
					}
				}
			}
			var texts = JSON.parse(contents);
			reassignIds(texts);
			if (type == 'Overwrite') {
				InsertTextStore.setTexts(texts);
			}
			else {
				InsertTextStore.addTexts(texts);
			}
			toast('Import successfully');
			return true;
		}
		
	};
	
	$('#import-button')
		.button()
		.bind('click', function(e) {
			var contents = $('#import-contents').val().trim();
			if (contents.length === 0) {
				$('#dialog')
					.html('Please enter content to import')
					.dialog({
						modal:		true,
						resizable:	false,
						title:		'Error',
						width:		200,
						height:		75
					});
				return false;
			}
			if (Import[$('#import-format').val()](contents, $('#import-type').val())) {
				reloadTextsTree();
				$('#import-contents').val('');
				$('#import-file').val('');
			}
		});
		
	if (window.File && window.FileReader && window.FileList && window.Blob) {
		$('#import-file').bind('change', function(e) {
			var files = e.target.files;
			
			var reader = new FileReader();
			reader.onload = function(e) {
				$('#import-contents').val(e.target.result);
			};
			reader.readAsText(files[0]);
			
		});
	}
	else {
		$('#import-file-container').remove();
	}
	
});