var InsertTextStore = {
	
	upgrade:	function(texts) {
		
		var lastVersion		= localStorage.lastVersion;
		var currentVersion	= localStorage.version;
		
		if (lastVersion !== currentVersion) {
			
			// upgrade from version 1.0
			if (lastVersion === "1.0") {
				
				var newTexts = [];
				
				for (var i=0, ilen=texts.length; i<ilen; i++) {
					
					newTexts.push({
						"id":		this.nextId(),
						"type":		"text",
						"level":	0,
						"parent":	0,
						"name":		texts[i].name,
						"text":		texts[i].text,
						"html":		false
					});
					
				}
				
				this.setTexts(newTexts);
				
				texts = newTexts;
				
				// upgrade lastVersion to current version
				localStorage.lastVersion = currentVersion;

			}
		
		}
		
		return texts;
		
	},
	
	texts:		null,
	
	getTexts:	function() {
		
		if (null === this.texts) {
			
			var texts = [];
			if (localStorage.texts) {
				texts = JSON.parse(localStorage.texts);
			}

			this.texts = this.upgrade(texts);
			
		}
		
		return this.texts;
		
	},
	
	setTexts:	function(texts) {
		
		if (texts) {
			if (typeof texts == 'string') {
				try {
					texts = JSON.parse(texts);
				}
				catch (e) {
					$('#dialog')
						.html('Content does not appear to be in the correct format')
						.dialog({
							modal:		true,
							resizable:	false,
							title:		'Error',
							width:		250,
							height:		75
						});
					return false;
				}
			}
			this.texts = texts;
		}
		
		localStorage.texts = JSON.stringify(this.texts);
		
	},
	
	addTexts:	function(newTexts) {
		
		if (newTexts && typeof newTexts == 'string') {
			newTexts = JSON.parse(newTexts);
		}
		
		newTexts = this.getTexts().concat(newTexts);
		
		this.setTexts(newTexts);
		
	},
	
	getTextById:	function(id, folder) {
		
		var texts = folder || this.getTexts();

		for (var i=0,ilen=texts.length; i<ilen; i++) {
			
			var node = texts[i];
			
			if (parseInt(node.id, 10) === parseInt(id, 10)) {

				return node;

			}

			if (node.type === "folder") {

				try {
					childNodeId = this.getTextById(id, node.items);
					return childNodeId;
				}
				catch (e) {}

			}

		}
		
		throw 'Node not found';
		
	},
	
	nextId:	function() {
		
		return localStorage.textId++;
		
	},
	
	getDefaultText:	function(type) {
		
		return {
			id:		this.nextId(),
			type:	type,
			level:	'0',
			parent:	'0',
			name:	'New ' + (type=='text' ? 'Text' : 'Folder'),
			text:	'',
			html:	InsertTextSettings.get('defaultRichText')
		};
		
	},
	
	add:	function(id, type, level, parent, name, text) {
		
		var texts = this.getTexts();
		
		var obj;
		if (typeof id === 'object') {
			obj = id;
		}
		else {
			obj = {
				"id":		id,
				"type":		type,
				"level":	level,
				"parent":	parent,
				"name":		name,
				"text":		text
			};
		}
		
		// if folder add items array
		if ('folder' === obj.type) {
			obj.items = [];
		}
		
		// add to texts
		texts.push(obj);
		
		// save
		this.setTexts(texts);
		
		return true;
		
	},
	
	update:	function(id, data) {
		
		// get text to update
		var text = this.getTextById(id);
		
		var lastParent = text.parent;
		
		// update data
		if (data.level) {
			text.level	= data.level;
		}
		if (data.name) {
			text.name	= data.name;
		}
		if (data.parent) {
			
			// if parent changed
			if (lastParent != data.parent) {
				
				// move it
				this.changeFolder(id, data.parent);
				
			}
			
			text.parent	= data.parent;
			
		}
		if (data.text) {
			text.text	= data.text;
		}
		if (data.html) {
			text.html	= data.html;
		}
		
		// save it
		this.setTexts();
		
	},
	
	/**
	 * Removes a text and return it
	 */
	remove:	function(id) {
		
		// get text to update
		var text = this.getTextById(id);
		
		// get parent
		var parent;
		try {
			parent = this.getTextById(text.parent).items;
		}
		catch (e) {
			parent = this.getTexts();
		}
		
		// get index of text
		for (var i=0, ilen=parent.length; i<ilen; i++) {
			
			// get current
			var current = parent[i];
			
			// if found
			if (parseInt(current.id, 10) === parseInt(text.id, 10)) {
								
				// remove it
				var text = parent.splice(i, 1);
				
				// update texts
				this.setTexts();
				
				return text;
				
			}
			
		}
		
		throw 'Unable to delete';
		
	},
	
	changeFolder:	function(text, parentId) {
		
		var text = typeof text == 'object' && text || this.getTextById(text);
		
		var parent;
		try {
			parent = this.getTextById(parentId);
		}
		catch (e) {
			parent = this.getTexts();
		}
		
		// remove text from current parent
		this.remove(text.id);
		
		// add it to new parent
		if (0 === parseInt(parentId, 10)) {
			parent.push(text);
		}
		else {
			parent.items.push(text);
		}
		
		// update
		this.setTexts();
		
	},
	
	move:	function(id, oldPosition, direction) {
		
		// get text to move and the parent
		var text = this.getTextById(id);
		var parent;
		try {
			parent = this.getTextById(text.parent).items;
		}
		catch(e) {
			parent = this.getTexts();
		}
		
		// remove text from parent
		parent.splice(oldPosition, 1);
		
		// add it back in the new position
		if (direction == 'up') {
			parent.splice(oldPosition-1, 0, text);
		}
		else {
			parent.splice(oldPosition+1, 0, text);
		}
		
		this.setTexts();
		
	}
	
};