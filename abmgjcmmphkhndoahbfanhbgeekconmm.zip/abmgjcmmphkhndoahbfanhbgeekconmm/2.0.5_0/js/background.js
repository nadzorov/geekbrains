// set version
localStorage.lastVersion	= localStorage.version || "1.0";
localStorage.version		= "2.0.2";

// text ids
localStorage.textId			= localStorage.textId || 1;

InsertTextMenu.generate();

// browser action click
chrome.browserAction.onClicked.addListener(function(tab) {
	window.open(chrome.extension.getURL('options.html'));
});